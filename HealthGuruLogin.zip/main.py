from flask import Flask,render_template,request
import mysql.connector
app=Flask(__name__)  # to pass name


@app.route('/')
def login():
    return render_template('login.html')

@app.route('/register')
def about():
     return render_template('register.html') #if we add about at end of url then we will go to about page
@app.route('/home')
def home():
     return render_template('home.html')

@app.route('/login_validation' ,methods=['POST','GET'])
def login_validation():
    email = request.form.get('email')
    password=request.form.get('password')





if __name__=="__main__":
    app.run(debug=True)
